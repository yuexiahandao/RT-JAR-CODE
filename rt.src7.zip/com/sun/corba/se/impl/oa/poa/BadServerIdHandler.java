package com.sun.corba.se.impl.oa.poa;

import com.sun.corba.se.spi.ior.ObjectKey;

public abstract interface BadServerIdHandler
{
  public abstract void handle(ObjectKey paramObjectKey);
}

/* Location:           C:\Program Files\Java\jdk1.7.0_79\jre\lib\rt.jar
 * Qualified Name:     com.sun.corba.se.impl.oa.poa.BadServerIdHandler
 * JD-Core Version:    0.6.2
 */