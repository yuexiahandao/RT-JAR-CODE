package com.sun.corba.se.impl.naming.namingutil;

public class NamingConstants
{
  public static final int IIOP_LENGTH = 4;
  public static final int RIRCOLON_LENGTH = 4;
  public static final int MAJORNUMBER_SUPPORTED = 1;
  public static final int MINORNUMBERMAX = 2;
}

/* Location:           C:\Program Files\Java\jdk1.7.0_79\jre\lib\rt.jar
 * Qualified Name:     com.sun.corba.se.impl.naming.namingutil.NamingConstants
 * JD-Core Version:    0.6.2
 */