/*    */ package com.sun.beans.decoder;
/*    */ 
/*    */ final class FalseElementHandler extends NullElementHandler
/*    */ {
/*    */   public Object getValue()
/*    */   {
/* 54 */     return Boolean.FALSE;
/*    */   }
/*    */ }

/* Location:           C:\Program Files\Java\jdk1.7.0_79\jre\lib\rt.jar
 * Qualified Name:     com.sun.beans.decoder.FalseElementHandler
 * JD-Core Version:    0.6.2
 */